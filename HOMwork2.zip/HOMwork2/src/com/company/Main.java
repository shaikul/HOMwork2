package com.company;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        double[] numbers = {2.3, 5.3, -6.6, 2.4, -9.9, 8.5};
        System.out.println(Arrays.toString(numbers));

        for (double number : numbers) {
            if (number < 0){
                continue;
            }

            System.out.println(number);
        }


    }


}

